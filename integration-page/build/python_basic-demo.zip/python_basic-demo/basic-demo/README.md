# Simple Integration UI build with React SDK

To implement, following articles from the docs where consumed:
 - https://console.integration.app/docs/getting-started/sdk
 - https://console.integration.app/w/637f613352b1ac2879d7cc34/docs/getting-started/authentication-token
 - https://console.integration.app/w/637f613352b1ac2879d7cc34/docs/getting-started/create-connection
 - https://console.integration.app/w/637f613352b1ac2879d7cc34/docs/flows/flow-instances
 - 


## Available Scripts

In the project directory, you can run:

### `npm start`
